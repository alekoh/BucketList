CREATE PROCEDURE `sp_addWish`(`p_title` VARCHAR(45), `p_description` VARCHAR(1000), `p_user_id` BIGINT(20))
  BEGIN
    insert into tbl_wish(
        wish_title,
        wish_description,
        wish_user_id,
        wish_date
    )
    values
    (
        p_title,
        p_description,
        p_user_id,
        NOW()
    );
END